package com.example.cueasap;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity{
GridView gridView;
    String[] codeNames = {"CODE RED","CODE BLACK","CODE VIOLET","CODE WHITE","CODE BLUE","CODE ORANGE","CODE GREEN","CODE BROWN"};
    int[] codeImages = {R.drawable.codered,R.drawable.codeblack,R.drawable.codeviolet,R.drawable.codewhite,R.drawable.codeblue,R.drawable.codeorange,R.drawable.codegreen,R.drawable.codebrown};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView = findViewById(R.id.gridview);

        CustomAdapter customAdapter = new CustomAdapter();
        gridView.setAdapter(customAdapter);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(),GridItemActivity.class);
                intent.putExtra("name",codeNames[i]);
                intent.putExtra("image",codeImages[i]);
                startActivity(intent);

            }
        });
    }
    private class CustomAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return codeImages.length;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            View view1 = getLayoutInflater().inflate(R.layout.row_data,null);

            TextView name = view1.findViewById(R.id.desc);
            ImageView image= view1.findViewById(R.id.codeword);

            name.setText(codeNames[i]);
            image.setImageResource(codeImages[i]);

            return view1;
        }
    }
}
