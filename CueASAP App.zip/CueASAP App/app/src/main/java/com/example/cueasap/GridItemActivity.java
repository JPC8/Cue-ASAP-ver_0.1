package com.example.cueasap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class GridItemActivity extends AppCompatActivity{

    TextView name;
    TextView box;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_item);

        name=findViewById(R.id.griddata);
        box=findViewById(R.id.colordata);

        Intent intent =getIntent();
        name.setText(intent.getStringExtra("name"));
        box.setText(intent.getStringExtra("box"));


    }
}
